#!/bin/bash
./gradlew clean test